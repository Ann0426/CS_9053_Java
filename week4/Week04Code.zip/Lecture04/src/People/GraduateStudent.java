package People;

public class GraduateStudent extends Student {

}
