package People;

public class Student extends Person {
	
	public String toString() {
		return "Student";
	}
}
