package People;

public class Faculty extends Employee {
		  
		public Faculty() {
		    System.out.println("(4) Faculty's no-arg constructor is invoked");
		  }

		
	public static void main(String[] argv) {
		Faculty faculty = new Faculty();
		return;
	}

}
