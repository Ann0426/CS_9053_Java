package People;

public class Person {
  public Person() {
    System.out.println("(1) Person's no-arg constructor is invoked");
    
  }
  /*
  public String toString() {
		return "Person";
	}
	*/
}
	
