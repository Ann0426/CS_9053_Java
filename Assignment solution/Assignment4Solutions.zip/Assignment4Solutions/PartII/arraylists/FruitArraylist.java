package arraylists;
import java.util.ArrayList;
import java.util.Random;
import fruit.*;

public class FruitArraylist {

	public static void main(String[] args) {
		
		// this ArrayList MUST be parameterized
		ArrayList<Fruit> fruitArrayList = new ArrayList<Fruit>();
		ArrayList toRemove;
		
		/*
		    1 non-rotten red Apple with a crisp texture and sweet taste
			2 rotten green Apple objects with a soft texture and tart taste
			3 non-rotten Lemon objects with a sour taste. “sourness” should be a random integer from 0-100 for each object
			2 rotten Orange objects of type “mandarin” with a sweet taste.

		 */
		
		// this is the variable you should retain to compare
		// to the other objects in the arraylist
		Apple goodRedApple1 = new Apple("sweet", "crisp", "red", false);
		Apple goodRedApple2 = new Apple("sweet", "crisp", "red", false);
		Apple rottenGreenApple1 = new Apple("tart", "soft", "green", true);
		Apple rottenGreenApple2 = new Apple("tart", "soft", "green", true);
		fruitArrayList.add(goodRedApple1);
		fruitArrayList.add(rottenGreenApple1);
		fruitArrayList.add(rottenGreenApple2);
		fruitArrayList.add(goodRedApple2);
		//(int sourness, String taste, boolean rotten)
		Lemon l1 = new Lemon(new Random().nextInt(100), "tart", false);
		Lemon l2 = new Lemon(new Random().nextInt(100), "tart", false);
		Lemon l3 = new Lemon(new Random().nextInt(100), "tart", false);
		Orange o1 = new Orange("mandarin", "sweet", true);
		Orange o2 = new Orange("mandarin", "sweet", true);
		fruitArrayList.add(l1);
		fruitArrayList.add(l2);
		fruitArrayList.add(l3);
		fruitArrayList.add(o1);
		fruitArrayList.add(o2);
		
		double total_sourness = 0;
		int num_lemons = 0;
		for (int i=0;i<fruitArrayList.size(); i++) {
			Fruit fruit = fruitArrayList.get(i);
			if (fruit == goodRedApple1) {
				System.out.println("index " + i + " is the same object. removing");
				fruitArrayList.remove(fruit);
			} else if (fruit.equals(goodRedApple1)) {
				System.out.println("index " + i + " is the a matching object. removing");
				fruitArrayList.remove(fruit);
			} else if (fruit instanceof Lemon) {
				Lemon l  = (Lemon)fruit;
				total_sourness += l.getSourness();
				num_lemons++;
			}
		}
		System.out.println("fruitArrayList is " + fruitArrayList);
		System.out.println("average sourness = " + (total_sourness/num_lemons));
	}
}
