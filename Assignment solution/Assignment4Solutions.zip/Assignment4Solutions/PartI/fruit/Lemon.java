package fruit;

public class Lemon extends Citrus {

	private int sourness;
	
	public Lemon() {
		super.setColor("Yellow");
	}
	
	public Lemon(int sourness, String taste, boolean rotten) {
		super(taste, "Yellow", rotten);
		this.setSourness(sourness);
	}

	public int getSourness() {
		return sourness;
	}

	public void setSourness(int sourness) {
		this.sourness = sourness;
	}
	
	public boolean equals(Object o) {
		
		if (o instanceof Lemon) {
			Lemon l = (Lemon)o;
			if (
				(this.sourness == l.getSourness()) &&
				(super.equals(l))) {
				return true;
			}
					
		}
		return false;
		
	}
	
	 /* You can do this manually using inheritance, or you can use the
	  * auto-generated toString
	public String toString() {
		return "Lemon: [" + super.toString() + ", sourness = " + sourness+"]";		
	}*/

	@Override
	public String toString() {
		return "Lemon [sourness=" + sourness + ", getTaste()=" + getTaste()
				+ ", getColor()=" + getColor() + ", isRotten()=" + isRotten() + ", getId()=" + getId() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + "]";
	}
}
