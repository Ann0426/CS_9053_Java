package fruit;

public class Fruit {
	private static int next_id = 0;
	private String color;
	private boolean rotten;
	private int id;
	
	public Fruit() {
		id = next_id;
		next_id++;
	}
	
	public Fruit(String color, boolean rotten) {
		this();
		this.color = color;
		this.rotten = rotten;
	}

	public static int getNext_id() {
		return next_id;
	}

	public static void setNext_id(int next_id) {
		Fruit.next_id = next_id;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public boolean isRotten() {
		return rotten;
	}

	public void setRotten(boolean rotten) {
		this.rotten = rotten;
	}

	public int getId() {
		return id;
	}
	
	public boolean equals(Object o) {
		if (o instanceof Fruit) {
			if (
				(
				((this.color == null) && ((Fruit)o).getColor() == null)
					||
				(this.color.equals(((Fruit)o).getColor()))) 
					&&
					(this.isRotten() == ((Fruit)o).isRotten())) {
				return true;
			}
		}
		return false;
	}

	@Override
	public String toString() {
		return "Fruit [color=" + this.color + ", rotten=" + this.rotten
				+ ", id=" + this.id + "]";
	}
	
}
