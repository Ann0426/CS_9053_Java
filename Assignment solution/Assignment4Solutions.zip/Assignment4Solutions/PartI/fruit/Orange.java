package fruit;

public class Orange extends Citrus {

	private String type;
	
	public Orange() {
		super.setColor("Orange");
	}
	
	public Orange(String type, String taste, boolean rotten) {
		super(taste, "Orange", rotten);
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public boolean equals(Object o) {
		
		boolean result = false;
		if (o instanceof Orange) {
			Orange or = (Orange)o;
			if ((this.type != null) && (or.getType() != null)) {
				result = this.type.equals(or.getType());
			} else if ((this.type == null) && (or.getType() == null)) {
				result = true;
			}
			if (result) {
				result = (super.equals(or)); 
			}
		}
		return result;
		
	}
	
	/* once again, the auto-generated toString is also acceptable,
	 * as long as you show all the attributes
	 */
	public String toString() {
		return "Orange: [" + super.toString() + ", type="+this.type +
				 "]";
	}
}
