package fruit;

public class Apple extends Fruit {

	private String taste;
	private String texture;
	
	public Apple() {
		
	}
	
	public Apple (String taste, String texture, String color, boolean rotten) {
		super(color,rotten);
		this.taste = taste;
		this.texture  = texture;
	}

	public String getTaste() {
		return taste;
	}

	public void setTaste(String taste) {
		this.taste = taste;
	}

	public String getTexture() {
		return texture;
	}

	public void setTexture(String texture) {
		this.texture = texture;
	}
	
	public boolean equals(Object o) {
		
		boolean result = false;
		if (o instanceof Apple) {
			Apple ap = (Apple)o;
			if ((this.taste != null) && (ap.getTaste() != null)) {
				
				if (this.taste.equals(ap.getTaste())) {
					result = true;
				}
			} else if ((this.taste == null) && (ap.getTaste() == null)) {
				result = true;
			}
			if (result) {
				if ((this.texture != null) && (ap.getTexture() != null)) {
					
					if (this.texture.equals(ap.getTexture())) {
						result = true;
					} else {
						result = false;
					}
				} else if ((this.texture == null) && (ap.getTexture() == null)) {
					result = true;
				} else {
					result = false;
				}
			}
			if (result) {
				result = super.equals(ap);
			}
		}
		return result;
		
	}

	@Override
	public String toString() {
		return "Apple [taste=" + taste + ", texture=" + texture + ", getColor()=" + getColor() + ", isRotten()="
				+ isRotten() + ", getId()=" + getId() + "]";
	}
	
	
}
