package fruit;

public class Inheritance {

	public static void main(String[] args) {
		// Here's some scratch space to experiment/debug your Fruit objects
		Apple a = new Apple();
		Orange o = new Orange();
		Lemon l = new Lemon();
		
		System.out.println("apple = " + a);
		System.out.println("orange = " + o);
		System.out.println("lemon = " + l);
		
		Apple a1 = new Apple();
		Orange o1 = new Orange();
		Lemon l1 = new Lemon();
		Apple a2 = new Apple("tart", "crisp", "red", false);
		Orange o2 = new Orange("navel", "sweet", true);
		Lemon l2 = new Lemon(5, "sour", true);
		
		System.out.println("a equals a1: " + a.equals(a1));
		System.out.println("o equals o1: " + o.equals(o1));
		System.out.println("l equals l1: " + l.equals(l1));
		System.out.println("a equals a2: " + a.equals(a2));
		System.out.println("o equals o2: " + o.equals(o2));
		System.out.println("l equals l2: " + l.equals(l2));
	}

}
