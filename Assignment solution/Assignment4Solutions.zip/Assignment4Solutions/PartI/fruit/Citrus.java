package fruit;

public class Citrus extends Fruit {
	
	private String taste;
	
	public Citrus() {
		
	}
	
	public Citrus(String taste, String color, boolean rotten) {
		super(color, rotten);
		this.setTaste(taste);
	}

	public String getTaste() {
		return taste;
	}

	public void setTaste(String taste) {
		this.taste = taste;
	}
	
	public boolean equals(Object o) {
		
		if (o instanceof Citrus) {
			Citrus c = (Citrus)o;
			if (
				(
				((this.taste == null) && (c.getTaste() == null))
				||
				(this.taste.equals(c.getTaste()))
				) &&
				(super.equals(c))) {
				return true;
			}
					
		}
		return false;
		
	}
	
	public String toString() {
		return "Citrus: ["+super.toString()+", taste="+this.taste +"]";
	}
}
