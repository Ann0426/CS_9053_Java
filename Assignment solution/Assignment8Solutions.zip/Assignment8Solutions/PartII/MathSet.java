import java.util.HashSet;
import java.util.Set;

public class MathSet<E> extends HashSet<E> {

	public Set<E> intersection(Set<E> s2) {
		
		Set<E> s = new MathSet<E>();
		for (E e : this) {
			if (s2.contains(e)) {
				s.add(e);
			}
		}
		return s;
		
	}
	
	public Set<E> union(Set<E> s2) {
		
		Set<E> s = new MathSet<E>();
		s.addAll(this);
		s.addAll(s2);
		return s;
	}
	
	public <T> Set<Pair<E,T>> cartesianProduct(Set<T> s2) {
		
		Set<Pair<E,T>> s= new MathSet<Pair<E,T>>();
		
		for (E e: this) {
			for (T t : s2) {
				Pair<E, T> p = new Pair<E,T>(e,t);
				s.add(p);
			}
		}
		return s;
	}
	
	public static void main(String[] args) {
		MathSet<Integer> m = new MathSet<Integer>();
		m.add(1);
		m.add(5);
		m.add(10);
		
		MathSet<Integer> m2 = new MathSet<Integer>();
		m2.add(5);
		m2.add(10);
		m2.add(20);
		
		System.out.println(m.intersection(m2));
		System.out.println(m.union(m2));
		
		MathSet<String> ms = new MathSet<String>();
		ms.add("Hello");
		ms.add("Goodbye");
		ms.add("Yo");
		
		System.out.println(ms.cartesianProduct(m));
		
	}
}
