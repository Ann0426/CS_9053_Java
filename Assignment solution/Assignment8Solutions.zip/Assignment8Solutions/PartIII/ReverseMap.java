import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class ReverseMap {

	public static Map<Object, Set<Object>> getInverted(Map<Object, Object> mp) {
		
		Map<Object, Set<Object>> m2 = new HashMap<Object, Set<Object>>();
		
		for (Entry<Object,Object> e : mp.entrySet()) {
			Object key = e.getKey();
			Object value = e.getValue();
			
			if (!m2.containsKey(value)) {
				Set s = new HashSet<Object>();
				s.add(key);
				m2.put(value, s);
			} else {
				Set s = m2.get(value);
				s.add(key);
				// I don't have to add this back because
				// "s" is a reference to the set we created
				// and inserted into the HashMap above, so changes to
				// the Set s are made to the same object that exists in
				// the HashMap
			}
		}
		return m2;
	}
	public static void main(String[] args) {
		Map<Object,Object> m = new HashMap<Object,Object>();
		m.put("Key1", new Integer(2));
		m.put("Key2", new Integer(5));
		m.put("Key4", new Integer(2));
		m.put("Key5", new Integer(8));
		m.put("Key6", new Integer(18));
		m.put("Key7", new Integer(24));
		System.out.println("hashmap is " + m);
		
		System.out.println("inverted: " + ReverseMap.getInverted(m));
		

	}

}
