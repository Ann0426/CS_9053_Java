import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WordFinder extends JFrame {

	JMenuBar menuBar;
	JMenu menu;
	JMenuItem menuItem;
	private JLabel findLabel;
	private JTextField searchBox;
	private JPanel topPanel;
	private JButton clearButton;
	private JTextArea wordsBox;
	JFileChooser jFileChooser;
	private static final int FRAME_WIDTH = 325;
	private static final int FRAME_HEIGHT = 175;
	WordList wordList;
	
	class SearchListener implements CaretListener {

		@Override
		public void caretUpdate(CaretEvent e) {
			System.out.println("filtering with "+ searchBox.getText());
			List searchResult = wordList.find(searchBox.getText());
			wordsBox.setText("");
			for (Object s : searchResult) {
				wordsBox.append((String)s + "\n");				
			}
			wordsBox.setCaretPosition(0);
			
		}
	}
	
	class OpenListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			int returnVal = jFileChooser.showOpenDialog(getParent());
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				System.out.println("You chose to open this file: " + jFileChooser.getSelectedFile().getAbsolutePath());
				try {
					InputStream in = new FileInputStream(jFileChooser.getSelectedFile().getAbsolutePath());
					wordList.load(in);
					List searchResult = wordList.find(searchBox.getText());
					for (Object s : searchResult) {
						wordsBox.append((String)s + "\n");
					}
					wordsBox.setCaretPosition(0);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	public WordFinder() {

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(FRAME_WIDTH, FRAME_HEIGHT);
		
		wordList = new WordList();
		
		wordsBox = new JTextArea(35,10);
		findLabel = new JLabel();
		searchBox = new JTextField(12);
		topPanel = new JPanel();
		clearButton = new JButton("Clear");
		jFileChooser = new JFileChooser(".");
		
		createMenus();
		
		topPanel.setLayout(new FlowLayout());
		topPanel.add(findLabel);
		topPanel.add(searchBox);
		topPanel.add(clearButton);
		findLabel.setText("Find:");
		this.setLayout(new BorderLayout());
		this.add(topPanel, BorderLayout.NORTH);
		
		JScrollPane listScroller = new JScrollPane(wordsBox);
		this.add(listScroller, BorderLayout.CENTER);
		listScroller.setPreferredSize(new Dimension(250, 80));

		searchBox.addCaretListener(new SearchListener());
		clearButton.addActionListener((e) -> {searchBox.setText(""); searchBox.postActionEvent();});

	}
	
	private void createMenus() {

		menuBar = new JMenuBar();
		menu = new JMenu("File");
		menuItem = new JMenuItem("Open", KeyEvent.VK_O);
		menuItem.addActionListener(new OpenListener());
		menu.add(menuItem);

		menu.addSeparator();
		menuItem = new JMenuItem("Exit", KeyEvent.VK_Q);
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		menu.add(menuItem);
		menuBar.add(menu);
		this.setJMenuBar(menuBar);
	}

	public static void main(String[] args) {

		WordFinder wordFinder = new WordFinder();
		wordFinder.setVisible(true);
	}
}
