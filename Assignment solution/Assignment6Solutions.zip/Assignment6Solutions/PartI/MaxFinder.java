import java.util.Collection;
import java.util.HashSet;

public class MaxFinder<T extends Number> {

	// two possibilities. Either maintain a collection of 
	// every number added or keep a running max average
	private T max;	
	
	// alternately
	private Collection<T> currentNums;
	
	
	public MaxFinder() {
		max = null;
		currentNums = new HashSet<T>(); // or ArrayList or anything iterable
	}
	
	public T max() {
	
		T currentMax = max;
		// alternately:
		currentMax = null;
		for (T v : currentNums) {
			if (v.doubleValue() > currentMax.doubleValue()) {
				currentMax = v;
			}
		}
		return currentMax;
	}
	
	public void add(T t) {
		if ((t == null) || (t.doubleValue() > max.doubleValue())) {
			max = t;
		}
		
		// alternately:
		currentNums.add(t);
		
	}
	
	public static void main (String[] args) {
		MaxFinder<Integer> m = new MaxFinder<Integer>();
	}
	
}
