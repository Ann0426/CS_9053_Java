package complex;

public class ComplexNumber extends Number implements Cloneable {

	private Double real;
	private Double imaginary;
	
	public ComplexNumber(Double real, Double imaginary) {
		this.real = real;
		this.imaginary = imaginary;
	}
	
	public ComplexNumber(double real, double imaginary) {
		this.real = new Double(real);
		this.imaginary = new Double(imaginary);
	}
	
	
	public Double getReal() {
		return real;
	}
	
	public Double getImaginary() {
		return imaginary;
	}
	
	@Override
	public int intValue() {
		return real.intValue();
	}

	@Override
	public long longValue() {

		return real.longValue();
	}

	@Override
	public float floatValue() {

		return real.floatValue();
	}

	@Override
	public double doubleValue() {

		return real.doubleValue();
	}
	
	@Override
	public String toString() {
		return real.toString() + " " + imaginary.toString() + "i";
	}
	
	@Override
	public Object clone() {
		ComplexNumber c = (ComplexNumber)super.clone();
		c.real = this.real;
		c.imaginary = this.imaginary;
		return c;
	}
	
	public static void main(String[] args) {
		Double testNan1 = new Double(5/0);
		Double testNan = new Double(5) / new Double(0);
		System.out.println(testNan);
		System.out.println(5.0/0);
		return;
	}

}
