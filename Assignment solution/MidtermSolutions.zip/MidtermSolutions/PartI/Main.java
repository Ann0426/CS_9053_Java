import java.io.*;

class Main {
	public static void main(String[] args) {
		FileReader file;
		try {
			file = new FileReader("data.txt");
			BufferedReader fileInput = new BufferedReader(file);
			String inLine = fileInput.readLine();
			while (inLine!= null) {
				String[] numbers = inLine.split(" ");
				try {
					Integer a = Integer.parseInt(numbers[0]);
					Integer b = Integer.parseInt(numbers[1]);
					try { 
						Integer c = a/b;
						System.out.println("result = " + c);
					} catch (ArithmeticException ae) {
						System.err.println("divide by zero exception");
					}
					inLine = fileInput.readLine();
				} catch (NumberFormatException nfe) {
					System.err.println("cannot parse integer: " + nfe.getMessage());
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
}
