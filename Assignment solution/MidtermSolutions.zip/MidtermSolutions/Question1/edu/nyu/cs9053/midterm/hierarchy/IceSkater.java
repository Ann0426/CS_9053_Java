package edu.nyu.cs9053.midterm.hierarchy;

public abstract class IceSkater extends WinterSportPlayer {

	private int skateSize;
	
	public IceSkater(String name, int age, int skateSize) {
		super(name, age);
		skateSize = this.skateSize;
	}

	public int getSkateSize() {
		return skateSize;
	}

	public void setSkateSize(int skateSize) {
		this.skateSize = skateSize;
	}

	
}
