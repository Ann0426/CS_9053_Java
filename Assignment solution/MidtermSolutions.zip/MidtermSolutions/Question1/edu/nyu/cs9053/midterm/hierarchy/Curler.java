package edu.nyu.cs9053.midterm.hierarchy;


public class Curler extends WinterSportPlayer {

	private String trouserPattern;
	private int brushLength;
	
	public Curler(String name, int age, String trouserPattern, int brushLength) {
		super(name, age);
		this.trouserPattern = trouserPattern;
		this.setBrushLength(brushLength);
	}
	
	public void setTrouserPattern(String trouserPattern) {
		this.trouserPattern = trouserPattern;
	}
	
	public String getTrouserPattern() {
		return this.trouserPattern;
	}

	public int getBrushLength() {
		return brushLength;
	}

	public void setBrushLength(int brushLength) {
		this.brushLength = brushLength;
	}
	
	public boolean equals(Object o) {
		if (o == this) {
			return true;
		}
		
		if (!(o instanceof Curler)) {
			return false;
		}
		
		Curler c = (Curler)o;
		
		if ( (this.getTrouserPattern().equals(c.getTrouserPattern())) && 
				(this.getBrushLength() == c.getBrushLength()) &&
				(this.getAge() == c.getAge()) && (this.getName().equals(c.getName()))) {
			return true;
		} else {
			return false;
		}
		
	}
}
