package edu.nyu.cs9053.midterm.hierarchy;

public class CrossCountrySkier extends Skier {

	public CrossCountrySkier(String name, int age, int skiLength) {
		super(name, age, skiLength);
	}

	public boolean equals(Object o) {
		
		if (o == this) {
			return true;
		}
		
		if (!(o instanceof CrossCountrySkier)) {
			return false;
		}
		
		CrossCountrySkier c = (CrossCountrySkier)o;
		
		if ( (this.getName().equals(c.getName())) && 
				(this.getAge() == c.getAge()) && 
				(this.getSkiLength() == c.getSkiLength())) {
			return true;
		} else {
			return false;
		}
	}
}
