package edu.nyu.cs9053.midterm.hierarchy;

public class Bobsledder extends Sledder {

	public Bobsledder(String name, int age, String color) {
		super(name, age, color);
	}

	public boolean equals(Object o) {
		
		if (o == this) {
			return true;
		}
		
		if (!(o instanceof Bobsledder)) {
			return false;
		}
		
		Bobsledder b = (Bobsledder)o;
		
		if ( (this.getName().equals(b.getName())) && 
				(this.getAge() == b.getAge()) &&
				(this.getSledColor().equals(b.getSledColor()))) {
			return true;
		} else {
			return false;
		}
			
	}
}
