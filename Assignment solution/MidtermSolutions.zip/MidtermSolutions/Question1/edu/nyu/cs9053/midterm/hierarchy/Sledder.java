package edu.nyu.cs9053.midterm.hierarchy;

public abstract class Sledder extends WinterSportPlayer {
	
	private String sledColor;
	
	public Sledder(String name, int age, String color) {
		super(name, age);
		this.setSledColor(color);
	}

	public String getSledColor() {
		return sledColor;
	}

	public void setSledColor(String sledColor) {
		this.sledColor = sledColor;
	}
}
