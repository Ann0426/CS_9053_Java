package edu.nyu.cs9053.midterm.hierarchy;

public class MogulSkier extends Skier {

	public MogulSkier(String name, int age, int skiLength) {
		super(name, age, skiLength);
	}
	
	public boolean equals(Object o) {
		
		if (o == this) {
			return true;
		}
		
		if (!(o instanceof MogulSkier)) {
			return false;
		}
		
		MogulSkier m = (MogulSkier)o;
		
		if ( (this.getName().equals(m.getName())) && (this.getAge() == m.getAge()) && 
				(this.getSkiLength() == m.getSkiLength())) {
			return true;
		} else {
			return false;
		}
	}

}
