package edu.nyu.cs9053.midterm.hierarchy;

public class Luger extends Sledder {

	public Luger(String name, int age, String color) {
		super(name, age, color);
	}
	
	public boolean equals(Object o) {

		if (o == this) {
			return true;
		}
		
		if (!(o instanceof Luger)) {
			return false;
		}
		
		Luger l = (Luger)o;
		
		if ( (this.getName().equals(l.getName())) && 
				(this.getAge() == l.getAge()) &&
				(this.getSledColor().equals(l.getSledColor())) ) {
			return true;
		} else {
			return false;
		}
			
	}

}
