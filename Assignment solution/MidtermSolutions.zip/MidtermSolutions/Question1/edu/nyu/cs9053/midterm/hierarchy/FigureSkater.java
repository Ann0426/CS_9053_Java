package edu.nyu.cs9053.midterm.hierarchy;

public class FigureSkater extends IceSkater {

	public FigureSkater(String name, int age, int skateSize) {
		super(name, age, skateSize);
	}
	
	public boolean equals(Object o) {
		
		if (o == this) {
			return true;
		}
		
		if (!(o instanceof FigureSkater)) {
			return false;
			
		}
		FigureSkater f = (FigureSkater)o;
		
		if ((this.getAge() == f.getAge()) &&
				(this.getName().equals(f.getName())) &&
				(this.getSkateSize() == f.getSkateSize())) {
			return true;
		} else {
			return false;
		}
	}

}
