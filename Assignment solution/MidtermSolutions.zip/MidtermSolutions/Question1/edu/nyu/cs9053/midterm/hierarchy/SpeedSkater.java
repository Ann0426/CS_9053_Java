package edu.nyu.cs9053.midterm.hierarchy;

public class SpeedSkater extends IceSkater {

	public SpeedSkater(String name, int age, int skateSize) {
		super(name, age, skateSize);
	}
	
	public boolean equals(Object o) {
		

		if (o == this) {
			return true;
		}
		
		if (!(o instanceof SpeedSkater)) {
			return false;
		}
		
		SpeedSkater s = (SpeedSkater)o;
		
		if ((this.getAge() == s.getAge()) &&
				(this.getName().equals(s.getName())) &&
				(this.getSkateSize() == s.getSkateSize())) {
			return true;
		} else {
			return false;
		}
	}

}
