
public class ExceptionWrongMatrixValues extends Exception {

	public ExceptionWrongMatrixValues() {
		super("Miscellaneous Wrong Matrix Values Error");
	}
	
	public ExceptionWrongMatrixValues(String msg) {
		super(msg);
	}
}
