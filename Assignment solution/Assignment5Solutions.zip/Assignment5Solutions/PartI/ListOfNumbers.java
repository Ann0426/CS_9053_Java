import java.io.*;
import java.util.List;
import java.util.ArrayList;
 
public class ListOfNumbers {
	
    private List<Integer> list;
    private static final int SIZE = 10;
 
    public ListOfNumbers () {
        list = new ArrayList<Integer>(SIZE);
        for (int i = 0; i < SIZE; i++)
            list.add(new Integer(i));
    }
    
    public void writeList() {
        PrintWriter out = null;
        try {
            System.out.println("Entering try statement");
            out = new PrintWriter(new FileWriter("outFile.txt"));
            for (int i = 0; i < SIZE; i++)
                out.println("Value at: " + i + " = " + list.get(i));
        } catch (IndexOutOfBoundsException e) {
            System.err.println("Caught IndexOutOfBoundsException: " +
                                 e.getMessage());
        } catch (IOException e) {
            System.err.println("Caught IOException: " + e.getMessage());
        } finally {
            if (out != null) {
                System.out.println("Closing PrintWriter");
                out.close();
            } else {
                System.out.println("PrintWriter not open");
            }
        }
    }
    
    public static void cat(File file) {
        RandomAccessFile input = null;
        String line = null;

        try {
			input = new RandomAccessFile(file, "r");
        } catch (FileNotFoundException fne) {
        	System.err.println("File " + file + " not found.");
        	return;
        }
        try {
        	while ((line = input.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException ioe) {
        	System.err.println("Error reading file: " + ioe.getMessage());
        	ioe.printStackTrace();
        } finally {
        
            if (input != null) {
                try {
					input.close();
				} catch (IOException ioe2) {
					System.err.println("Error closing file");
					ioe2.printStackTrace();
				}
            }
        }
    }

}
