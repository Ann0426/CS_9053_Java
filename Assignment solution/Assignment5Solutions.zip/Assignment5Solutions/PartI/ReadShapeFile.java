import java.io.*;
import java.util.ArrayList;

import shapes.*;

/* your tasks:
 * create a class called ShapeException
 * createShape should throw a ShapeException
 * in main(), you should catch the ShapeException
 * 
 */
public class ReadShapeFile {

	public static GeometricObject createShape(String shapeName) 
			throws ShapeException{
		switch (shapeName) {
			case "Circle":
				return new Circle();
			case "Square":
				return new Square();
			case "Rectangle":
				return new Rectangle();
			default:
				throw new ShapeException(shapeName);
				
		}

	}
	
	public static void main(String[] args) {
		ArrayList<GeometricObject> shapeList = new ArrayList<GeometricObject>();
		File f = new File("shapes.txt");
		FileReader reader = null;
		try {
			reader = new FileReader(f);
		} catch (FileNotFoundException e) {
			
			System.err.println("Cannot find file shapes.txt");
			System.exit(1);
		}
		BufferedReader in = new BufferedReader(reader);
		String inString = null;
		try {
			inString = in.readLine();
		} catch (IOException e) {
			System.err.println("error reading file");
			System.exit(1);
		}
		while (inString != null) {
			try {
				GeometricObject shape = createShape(inString);
				shapeList.add(shape);
			} catch (ShapeException se) {
				System.err.println("Cannot create shape: " + inString);
			} 
			try {
				inString = in.readLine();
			} catch (IOException e) {
				System.err.println("error reading file");
				break;
			}
		} 
		assert false;
		System.out.println(shapeList);
	}
}
