
public class GravityCalculator {
	
	public static void main(String[] args) {
		double a = -9.81;
		double t = 10;
		double vi = 0;
		double xi = 0;
		
		double finalPosition = 0.5*a*t*t + vi*t + xi;
		System.out.println("final position is " + finalPosition);
	}
	
}
