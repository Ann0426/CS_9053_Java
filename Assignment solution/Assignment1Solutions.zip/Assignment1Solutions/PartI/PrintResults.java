
public class PrintResults {

	public static void main(String[] args) {
		
		System.out.println("The value of 1+1 is " + (1+1));
		int a = 10 + 5;
		System.out.println("The value of a is " + a);
		int b = 50 - 23;
		System.out.println("The value of b is " + b);
		int c = 12 * 13;
		System.out.println("The value of c is " + c);
		double d = 20.0 / 3.0;
		System.out.println("The value of d is " + d);
		int e = 100 % 7;
		System.out.println("The value of e is " + e);
		double f = Math.pow(4, 3);
		System.out.println("The value of f is " + f);
		
		// or
		System.out.println("a = " + a + ", b = " + b + ", c = " + c + ", d = " + d + ", e = "+ e + ", f = " +f);
	}
}
