import java.util.Scanner;

public class MuayThai {

	public static int getMinWeight(int weight) {
		// this takes a weight and returns the "min weight" for the
		// weight class
		int minWeight = 0;
		if (weight < 112) {
			minWeight = 0;
		} else if (weight < 115) {
			minWeight = 112;
		} else if (weight < 118) {
			minWeight = 115;
		} else if (weight < 122) {
			minWeight = 118;
		} else if (weight < 126) {
			minWeight = 122;
		} else if (weight < 130) {
			minWeight = 126;
		} else if (weight < 135) {
			minWeight = 130;
		} else if (weight < 140) {
			minWeight = 135;
		} else if (weight < 147) {
			minWeight = 140;
		} else if (weight < 154) {
			minWeight = 147;
		} else if (weight < 160) {
			minWeight = 154;
		} else if (weight < 167) {
			minWeight = 160;
		} else if (weight < 175) {
			minWeight = 167;
		} else if (weight < 183) {
			minWeight = 175;
		} else if (weight < 190) {
			minWeight = 183;
		} else if (weight < 220) {
			minWeight = 190;
		} else {
			minWeight = 220;
		}
		
		return minWeight;
	}
	
	public static String getWeightClass(int weight) {
		
		String weightClass = "Super heavyweight";
		// use a switch statement to assign the correct
		// value to weightClass and return the result
		int minWeight = getMinWeight(weight);
		switch (minWeight) {
		case 0:
			weightClass = "Flyweight";
			break;
		case 112:
			weightClass = "Super flyweight";
			break;
		case 115:
			weightClass = "Bantamweight";
			break;
		case 118:
			weightClass = "Super bantamweight";
			break;
		case 122:
			weightClass = "Featherweight";
			break;
		case 126:
			weightClass = "Super featherweight";
			break;
		case 130:
			weightClass = "Lightweight";
			break;
		case 135:
			weightClass = "Super lightweight";
			break;
		case 140:
			weightClass = "Welterweight";
			break;
		case 147:
			weightClass = "Super welterweight";
			break;
		case 154:
			weightClass = "Middleweight";
			break;
		case 160:
			weightClass = "Super middleweight";
			break;
		case 167:
			weightClass = "Light heavyweight";
			break;
		case 175:
			weightClass = "Super light heavyweight";
			break;
		case 183:
			weightClass = "Cruiserweight";
			break;
		case 190:
			weightClass = "Heavyweight";
			break;
		default:
			weightClass = "Super heavyweight";
			
		}
		
		return weightClass;
	}
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.print("Input weight in pounds: ");
		int pounds = in.nextInt();
		
		// if pounds is greater or equal to zero
		if (pounds >= 0) {
			String weightClass = getWeightClass(pounds);
			System.out.println("Weight class for " + pounds + " is " + weightClass);
		} else {
			// if for some reason you put in a negative number of pounds:
			System.out.println("Invalid weight value");
		}
	}
}
