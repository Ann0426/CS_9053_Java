
public class LoopSum {

	public static int sum100() {
	
		int sum = 0;
		for (int i = 1; i <= 100;i++) {
			sum += i;
		}
		
		/* alternately: */
		sum = 0;
		int counter = 1;
		while (counter <= 100) {
			sum += counter;
			counter += 1;
		}
		
		/* alternately: */
		sum = 0;
		counter = 1;
		do {
			sum += counter;
			counter += 1;
		} while (counter <= 100);
		
		return sum;
	}
	
	public static int sumN(int n) {
		int sum = 0;
		for (int i = 1; i <= n ; i++) {
			sum += i;
		}
		return sum;
	}
	
	public static void main(String[] args) {
		System.out.println("result of sum100 is " + sum100());
		System.out.println("result of sumN for n = 99 is " + sumN(99));
	}
	
}
