import java.util.Scanner;

public class NumberToEnglish {

	/* there are lots of ways of doing this. the best is 
	 * probably a recursive algorithm, which I have not covered.
	 * This implementation is the most straightforward.
	 */
	public static String zeroToTwenty(int num) {
		String returnVal = "";
		switch(num) {
			case 0:
				returnVal = "zero";
				break;
			case 1:
				returnVal =  "one";
				break;
			case 2:
				returnVal =  "two";
				break;
			case 3:
				returnVal =  "three";
				break;
			case 4:
				returnVal =  "four";
				break;
			case 5:
				returnVal =  "five";
				break;
			case 6:
				returnVal =  "six";
				break;
			case 7:
				returnVal =  "seven";
				break;
			case 8:
				returnVal =  "eight";
				break;
			case 9:
				returnVal =  "nine";
				break;
			case 10:
				returnVal =  "ten";
				break;
			case 11:
				returnVal =  "eleven";
				break;
			case 12:
				returnVal =  "twelve";
				break;
			case 13:
				returnVal =  "thirteen";
				break;
			case 14:
				returnVal =  "fourteen";
				break;
			case 15:
				returnVal =  "fifteen";
				break;
			case 16:
				returnVal =  "sixteen";
				break;
			case 17:
				returnVal =  "seventeen";
				break;
			case 18:
				returnVal =  "eighteen";
				break;
			case 19:
				returnVal =  "nineteen";
				break;
			case 20:
				returnVal =  "twenty";
				break;
			case 30:
				returnVal =  "thirty";
				break;
			case 40:
				returnVal =  "forty";
				break;
			case 50:
				returnVal =  "fifty";
				break;
			case 60:
				returnVal =  "sixty";
				break;
			case 70:
				returnVal =  "seventy";
				break;
			case 80:
				returnVal =  "eighty";
				break;
			case 90:
				returnVal =  "ninety";
				break;
		}
		return returnVal;
	}
	
	public static String tensToEnglish(int num) {
		String englishNumber = "";
		int ones = num % 10;
		int tens = num - ones;
		if (tens > 0) {
			englishNumber += zeroToTwenty(tens);
		}
		if (ones > 0) {
			englishNumber += " " + zeroToTwenty(ones);
		}
		return englishNumber.trim();
	}
	
	public static String hundredsToEnglish(int num) {
		String englishNumber = "";
		// assumes positive at this point
		int hundreds = num / 100;
		if (hundreds > 0) {
			englishNumber += zeroToTwenty(hundreds);
			englishNumber += " hundred";
		}
		int remainder = num % 100;
		englishNumber += " " + tensToEnglish(remainder);
		return englishNumber.trim();
	}
	
	public static String numberToEnglish(int num) {
		String englishNumber = "";
		if (num < 0) {
			englishNumber += "negative";
			num = -num;
		}
		int millions = num / 1000000;
		if (millions > 0) {
			englishNumber += "  " + hundredsToEnglish(millions) + " million";
			num %= 1000000;
		}
		int thousands = num / 1000;
		if (thousands > 0) {
			englishNumber += " " + hundredsToEnglish(thousands) + " thousand";
			num %= 1000;
		}
		englishNumber += " " + hundredsToEnglish(num);
		return englishNumber.trim();
	}
	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		while(true) {
			System.out.print("Enter a number: " );
		
			int number = in.nextInt();
		
			System.out.println("The number " + number + " in English is " + NumberToEnglish.numberToEnglish(number));
		}
	}
}
