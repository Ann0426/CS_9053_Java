
public class Factorial {

	public static int fact(int arg) {
		int result = 1;
		while (arg >= 1) {
			
			result *= arg;
			arg--;
			
		}
		return result;
	}
	
	public static void main(String[] args) {
		int val = 0;
		System.out.println(fact(0));
		System.out.println(fact(1));
		System.out.println(fact(2));
		System.out.println(fact(5));
		System.out.println(fact(6));
		System.out.println(fact(9));
		
	}
}
