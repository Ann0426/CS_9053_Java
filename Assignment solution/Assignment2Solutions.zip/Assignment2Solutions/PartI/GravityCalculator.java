import java.util.Scanner;

public class GravityCalculator {

	public static double calculatePosition(double t, double vi, double xi) {
		double a = -9.81;
		return 0.5*a*t*t + vi*t + xi;
	}
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter starting position: ");
		double xi = in.nextDouble();
		System.out.print("Enter starting velocity: "); 
		double vi = in.nextDouble();
		System.out.print("Enter time: "); 
		double t = in.nextDouble();
		double xt = calculatePosition(t, vi, xi);
		System.out.printf("Position at t = " + t + " for initial position "+
							xi + " and initial velocity " + vi + 
							" is %.2f\n", xt);
		
	}
}
