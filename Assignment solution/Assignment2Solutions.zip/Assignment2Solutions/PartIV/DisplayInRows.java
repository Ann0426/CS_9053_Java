import java.util.Arrays;

public class DisplayInRows {

	static final int ROW_LENGTH = 10;
	
	public static void main(String[] args) {
		
		int[] intArray = new int[100];
		
		for (int i=0;i< intArray.length;i++) {
			intArray[i] = (int)(Math.random()*100);
		}

		System.out.println("Original array: " + Arrays.toString(intArray));
		for (int i=0;i< 10;i++) {

			for (int j=0;j< ROW_LENGTH;j++) {
				System.out.print(intArray[ROW_LENGTH*i + j] + " ");
			}
			System.out.println();
		}
	}
}
