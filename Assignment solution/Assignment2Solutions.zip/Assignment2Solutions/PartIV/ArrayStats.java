
public class ArrayStats {

	public static void main(String[] args) {
		int[] intArray = new int[50];
		
		int smallestValue = Integer.MAX_VALUE;
		int largestValue = Integer.MIN_VALUE;
		double meanAverage;
		double sum=0;
		
		/* initialize the source Array */
		for (int i = 0;i < intArray.length; i++) {
			intArray[i] = (int)(Math.random()*100);
		}
		
		for (int i = 0;i<intArray.length;i++) {
			sum += intArray[i];
			if (intArray[i] > largestValue) {
				largestValue = intArray[i];
			}
			if (intArray[i] < smallestValue) {
				smallestValue = intArray[i];
			}
		}
		
		/* if "sum" were an integer, then you'd have to make sure 
		 * you did floating point division, not integer division here:
		 */
		meanAverage = sum/intArray.length;
		
		System.out.println("Smallest value in the array is " + 
							smallestValue);
		System.out.println("Largest value in the array is " + 
							largestValue);
		System.out.println("Mean average value of array elements is " + 
							meanAverage);
	}
}
