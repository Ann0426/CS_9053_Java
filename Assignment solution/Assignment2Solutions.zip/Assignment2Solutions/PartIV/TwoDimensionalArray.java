import java.util.Arrays;

public class TwoDimensionalArray {

	public static void main(String[] args) {
		
		int[][] twoDimArray = new int[2][5];
		int[] arrayOne = {5, 9, 55, 23, 89};
		int[] arrayTwo = {15, 3, 23, 19, 64};
		
		/* copy arrayOne and arrayTwo into twoDimArray */
		/* print out the first list of 5 numbers in twoDimArray
		 * on one line, and the second list of 5 numbers in twoDimArray
		 * on the next line
		 */
		
		/* the solution should use nested loops: one loop to loop over
		 * each array in twoDimArray, and one loop to loop over each element
		 * in that array
		 */
		
		/* just assigning the reference of arrayOne to twoDimArray[0]
		 * and the reference of arrayTwo to twoDimArray[1] is wrong:
		 * 
		 * twoDimArray[0] = arrayOne   <---
		 * twoDimArray[1] = arrayTwo      |
		 *    ^                           |
		 *    |                           |
		 *    This is bad and you won't get credit for that.
		 */
		for (int i= 0;i<2;i++) {
			
			int[] srcArray;
			if (i == 0)
				srcArray=arrayOne;
			else
				srcArray=arrayTwo;
			for (int j=0;j<srcArray.length;j++) {
				twoDimArray[i][j] = srcArray[j];
			}
		}
		System.out.println("twoDimArray is " + 
							Arrays.deepToString(twoDimArray));
	}
}
