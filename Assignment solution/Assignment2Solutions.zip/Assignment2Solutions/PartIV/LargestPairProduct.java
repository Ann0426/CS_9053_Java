
public class LargestPairProduct {

	public static void main(String[] args) {
		
		int[] intArray = {17, 1, 3, 12, 39, 4, 76, 4, 31, 87};
		int product = Integer.MIN_VALUE;
		
		
		for (int i = 0;i<intArray.length;i++) {
			for (int j = 0;j<intArray.length;j++) {
				if (i == j)
					continue;
				int testProduct = intArray[i]*intArray[j];
				if (testProduct > product) {
					product = testProduct;
				}
			}			
		}
		System.out.println("Maximum product of all pairs in the array: " +
				product);
	}
}
