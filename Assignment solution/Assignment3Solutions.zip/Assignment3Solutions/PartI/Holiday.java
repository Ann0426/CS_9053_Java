
public class Holiday {
	private String name;
	private int day;
	private String month;
	
	public Holiday(String name, int day, String month) {
		this.name = name;
		this.day = day;
		this.month = month;
	}
	
	public static boolean inSameMonth(Holiday h1, Holiday h2) {
		// because we are in the Holiday class, we can access
		// h1's and h2's private fields without having to use
		// getters
		if (h1.month.equals(h2.month)) {
			return true;
		} else {
			return false;
		}
	}
	
	public static double avgDate (Holiday[] holidays) {
		double totalDate = 0;
		for (int i=0; i <holidays.length;i++) {
			totalDate += holidays[i].day;
		}
		return totalDate/holidays.length;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}
	
	public String toString() {
		return this.name + ": " + this.month + " " + this.day;
	}
	
	public static void main(String[] args) {

		Holiday[] holidays = new Holiday[5];
		holidays[0] = new Holiday("May Day", 1, "May");
		
		Holiday independenceDay = new Holiday("Independence Day", 4, "July");
		System.out.println(independenceDay); // toString is called implicitly
	}
}
