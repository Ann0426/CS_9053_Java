
public class Ellipse {

	private static int nextId = 0;
	private int id;
	private double semiMajorAxis = 2.0;
	private double semiMinorAxis = 1.0;
	
	public Ellipse() {
		id = nextId++;
	}
	
	public Ellipse(double a, double b) {
		this();
		// the major axis of an ellipse is always larger. 
		// So if you screw it up, I will fix it for you
		// (this is not a requirement for full credit)
		if (b > a) {
			semiMajorAxis = b;
			semiMinorAxis = a;
		} else {
			semiMajorAxis = a;
			semiMinorAxis = b;
		}
	}
	
	public double getSemiMajorAxis() {
		return this.semiMajorAxis;
	}
	
	public double getSemiMinorAxis() {
		return this.semiMinorAxis;
	}
	
	public double getArea() {
		return semiMajorAxis*semiMinorAxis*Math.PI;
	}
	
	public int getId() {
		return this.id;
	}
}
