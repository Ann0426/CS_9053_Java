package simplegui;
import javax.swing.JOptionPane;

public class SimpleDialog {
	
	
		public static void main(String[] args) {
			
			JOptionPane.showMessageDialog(null, "This is a dialog");
		}
}
