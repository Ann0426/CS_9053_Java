package arraylists;
import java.util.ArrayList;

import fruit.*;

public class FruitArraylist {

	public static void main(String[] args) {
		
		// this ArrayList MUST be parameterized
		ArrayList fruitArrayList;
		
		// this is the variable you should retain to compare
		// to the other objects in the arraylist
		Apple rottenGreenApple1;
	}
}
