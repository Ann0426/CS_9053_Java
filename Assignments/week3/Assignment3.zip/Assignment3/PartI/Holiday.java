
public class Holiday {
	private String name;
	private int day;
	private String month;
	
	public static void main(String[] args) {
		
		Holiday[] holidays = new Holiday[5];
		holidays[0] = new Holiday("May Day", 1, "May");
		
	}
}
