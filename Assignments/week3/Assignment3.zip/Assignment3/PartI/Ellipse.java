
public class Ellipse {
	
}
