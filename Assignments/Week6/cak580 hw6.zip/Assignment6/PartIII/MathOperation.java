
public interface MathOperation {

	abstract double operation(double a, double b);

}
