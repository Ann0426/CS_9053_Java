
public class PrintResults {

	public static void main(String[] args) {
		
		
		int a = 10 + 5;
		int b = 50 - 23;
		int c = 12 * 13;
		double d = 20.0 / 3.0;
		int e = 100 % 7;
		double f = Math.pow(4, 3);
		System.out.println("The value of a is " + (10 + 5));
		System.out.println("The value of b is " + (50 - 23));
		System.out.println("The value of c is " + (12 * 13));
		System.out.println("The value of d is " + (20.0 / 3.0));
		System.out.println("The value of e is " + (100 % 7));
		System.out.println("The value of f is " + (Math.pow(4, 3)));

	}
}
