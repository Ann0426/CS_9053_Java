

public class MyInitials {
    
    /*  This program prints my initials (CAK) in big letters,
        where each letter is nine lines tall.
    */
 
    public static void main(String[] args) {
       System.out.println();
       System.out.println("            CCC     A   K   k");
       System.out.println("           C    C  A A  K  k    ");
       System.out.println("           C      A   A K k   ");
       System.out.println("           C      AAAAA Kk   ");
       System.out.println("           C      A   A K k");
       System.out.println("           C   C  A   A K  k");
       System.out.println("            CCC   A   A K   k");
       
       System.out.println();
    }  // end main()

 }  // end class