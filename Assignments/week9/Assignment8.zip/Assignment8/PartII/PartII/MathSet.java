import java.util.HashSet;
import java.util.Set;

public class MathSet<E> extends HashSet<E> {

	public Set<E> intersection(Set<E> s2) {

		
	}
	
	public Set<E> union(Set<E> s2) {

	}
	
	public <T> Set<Pair<E,T>> cartesianProduct(Set<T> s2) {
		

	}
	
	public static void main(String[] args) {
		// create two MathSet objects of the same type.
		// See if union and intersection works.
		
		// create another MathSet object of a different type
		// calculate the cartesian product of this set with one of the
		// above sets
	}
}
