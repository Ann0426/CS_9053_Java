
public class GravityCalculator {

	public static double calculatePosition() {
		double a = -9.81;
		return -1;
	}
	
	public static void main(String[] args) {
		
	}
}
