
public class Factorial {

	public static void main(String[] args) {
		int val = 0;
	}
}
