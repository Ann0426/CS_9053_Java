
public class LoopSum {

	public static int sum100() {
	
		return -1;
	}
	
	public static int sumN() {
		
		return -1;
	}
	
	public static void main(String[] args) {
		
	}
	
}
