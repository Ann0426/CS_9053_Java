import java.util.Scanner;

public class MuayThai {

	public static String getWeightClass(int weight) {
		
		String weightClass = null;
		// use a switch statement to assign the correct
		// value to weightClass and return the result
		
		return weightClass;
	}
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		
		System.out.print("Input weight in pounds: ");
		int pounds = in.nextInt();
		
		// if pounds is greater than zero
		System.out.println("Weight class for " + pounds + " is ");
		
		// if for some reason you put in a negative number of pounds:
		System.out.println("Invalid weight value");
	}
}
