
public class WindChill {

	public static double windChill() {
		
		return -1;
	}
	
	public static void main(String[] args) {
		
		double temp;
		double windSpeed;
		
		double windChillTemp;
		
		// if the wind chill is valid:
		System.out.println("For a temperature of " + temp + 
							" with wind speed of " + windSpeed + 
							", the wind chill is " + windChillTemp);
		// if the wind chill is not valid:
		System.out.println("Cannot calculate a valid wind chill for this temperate and/or wind speed");
	}
}
