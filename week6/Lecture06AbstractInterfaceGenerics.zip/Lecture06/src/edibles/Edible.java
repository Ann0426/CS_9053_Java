package edibles;

public interface Edible {
	
		public abstract String howToEat();
}
