
public class DoWhileLoop {

	public static void main(String[] args) {
	
		int i = 0;
		do {
			System.out.println("Welcome to Java!");
			i++;
		} while (i < 100);
		
	}
	
}
