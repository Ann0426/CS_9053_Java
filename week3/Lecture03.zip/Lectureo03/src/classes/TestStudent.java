package classes;

public class TestStudent {

	public static void main(String[] args) {
		Student student = new Student();
	    System.out.println("name? " + student.name); 
	    System.out.println("age? " + student.age); 
	    System.out.println("isScienceMajor? " + student.isScienceMajor); 
	    System.out.println("gender? " + student.gender); 
	    
	    /**
	     * 
	     * int x; // x has no default value
    		String y; // y has no default value
    	System.out.println("x is " + x); 
    	System.out.println("y is " + y); 

	     * 
	     */
	}

}
