package classes;

public class Student {

	String name; // name has default value null
	int age; // age has default value 0
	boolean isScienceMajor; // isScienceMajor has default value false
	char gender; // c has default value '\u0000'

}
