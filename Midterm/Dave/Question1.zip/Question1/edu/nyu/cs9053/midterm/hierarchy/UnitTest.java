package edu.nyu.cs9053.midterm.hierarchy;

public class UnitTest {
    public static void main(String[] args) {
        System.out.println("Inheritance Unit Test");
    }
}
