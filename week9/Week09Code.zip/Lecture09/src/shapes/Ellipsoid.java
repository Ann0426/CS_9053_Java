package shapes;

public abstract class Ellipsoid extends Circle {

}
