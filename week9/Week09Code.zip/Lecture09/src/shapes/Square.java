package shapes;

public class Square extends Rectangle {

		public Square() {
			
		}
}
