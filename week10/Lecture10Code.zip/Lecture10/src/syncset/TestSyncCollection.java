package syncset;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class TestSyncCollection {

	public static void main(String[] args) {
		Collection<Integer> syncCollection = Collections.synchronizedCollection(new ArrayList<>());
		Collection<Integer> unsyncCollection = new ArrayList<Integer>();
		Runnable badlistOperation = () -> {
			unsyncCollection.addAll(Arrays.asList(1, 2, 3, 4, 5, 6));
		};
	    Runnable listOperations = () -> {
	        syncCollection.addAll(Arrays.asList(1, 2, 3, 4, 5, 6));
	    };
	     
	    Thread[] syncListThreads = new Thread[100];
	    for (int i=0;i<100;i++) {
	    	syncListThreads[i] = new Thread(listOperations);
	    }
	    
	    Thread[] badlistThreads = new Thread[100];
	    for (int i=0;i<100;i++) {
	    	badlistThreads[i] = new Thread(badlistOperation);
	    }
	    
	    for (Thread t : syncListThreads) {
	    	t.start();
	    }
	    for (Thread t : badlistThreads) {
	    	t.start();
	    }
	    
	    try {
		    for (Thread t : syncListThreads) {
		    	t.join();
		    }
		    for (Thread t : badlistThreads) {
		    	t.join();
		    }
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	    System.out.println("syncCollection size is " + syncCollection.size() + ": "+ syncCollection);
	    System.out.println("unsyncSet size is " + unsyncCollection.size() +": " + unsyncCollection);
	}
}
