package synclists;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;

public class IteratorSafeListTest {
	private List<Integer> safeList = Collections.synchronizedList(new ArrayList<>());
	 
    public IteratorSafeListTest() {
        for (int i = 0; i < 10_000; i++) {
        	safeList.add(i);
        }
    }
 
    public void runUpdateThread() {
        Thread thread1 = new Thread(new Runnable() {
 
            public void run() {
                for (int i = 10_000; i < 20_000; i++) {
                	System.out.println("adding");
                	safeList.add(i);
                }
            }
        });
 
        thread1.start();
    }
 
 
    public void runIteratorThread() {
        Thread thread2 = new Thread(new Runnable() {
 
            public void run() {
                ListIterator<Integer> iterator = safeList.listIterator();
                //synchronized (safeList) {
	                while (iterator.hasNext()) {
	                    Integer number = iterator.next();
	                    System.out.println(number);
	                }
                //}
            }
        });
 
        thread2.start();
    }
 
    public static void main(String[] args) {
    	IteratorSafeListTest tester = new IteratorSafeListTest();

        tester.runUpdateThread();
        tester.runIteratorThread();
    }
}
