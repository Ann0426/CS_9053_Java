package bankthreads;

public class ThreadTest {
	public static final int DELAY = 10;
	public static final int STEPS = 100;
	public static final double MAX_AMOUNT=1000;
	
	public static void transfer (int fromAcct1, int toAcct1, 
							int fromAcct2, int toAcct2) {
		Bank bank = new Bank(4, 100000);
		
		Runnable task1 = () ->
		{
			try {
				for (int i = 0; i< STEPS ; i++) {
					double amount = MAX_AMOUNT * Math.random();
					bank.transfer(fromAcct1, toAcct1, amount);
					Thread.sleep((int) (DELAY*Math.random()));
				}
			}
			catch (InterruptedException e) {
			}
		};
		
		Runnable task2 = () ->
		{
			try 
			{
				for (int i=0; i < STEPS; i++) 
				{
					double amount = MAX_AMOUNT * Math.random();
					bank.transfer(fromAcct2,toAcct2,amount);
					Thread.sleep((int)(DELAY*Math.random()));
				}
			}
			catch (InterruptedException e) {
				
			}
		};
		
		new Thread(task1).start();
		new Thread(task2).start();
	}
	

	public static void main(String[] args) {
		ThreadTest.transfer(0,1, 2, 3);
	}
	
	
	
}

