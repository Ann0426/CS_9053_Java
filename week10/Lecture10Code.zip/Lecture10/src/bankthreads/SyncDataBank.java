package bankthreads;
import java.util.*;

public class SyncDataBank extends Bank {

	private Account[] syncAccounts;
	
	public SyncDataBank(int n, double initialBalance) {
		super(n, initialBalance);
		syncAccounts = new Account[n];
		for (int j = 0;j< n ; j++) {
			syncAccounts[j] = new Account(initialBalance);
		}
	}
	
	public void transfer(int from, int to, double amount) 
	{
		/* attempt to grab both sources.
		 * if you get one resource, but no the other, let both go and wait
		 * try again
		 * 
		 * Java can do that, but we won't go into that here.
		 * 
		 */
		synchronized(syncAccounts[from]) {
			if (syncAccounts[from].getBalance() < amount) return;
			System.out.print(Thread.currentThread());
			syncAccounts[from].withdraw(amount);
			System.out.printf(" %10.2f from %d to %d",  amount, from, to);
			synchronized(syncAccounts[to]) {
				syncAccounts[to].deposit(amount);
				System.out.printf(" Total Balance: %10.2f%n", getTotalBalance());
			}
		}

	}
	

}


// add synchronized(from) and then synchronized(to) blocks
