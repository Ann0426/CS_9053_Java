package bankthreads;
import java.util.*;

public class SyncMethodBank extends Bank {

	
	public SyncMethodBank(int n, double initialBalance) {
		super(n, initialBalance);
	}
	
	public synchronized void transfer(int from, int to, double amount) 
	{
		super.transfer(from, to, amount);
	}
	
}
