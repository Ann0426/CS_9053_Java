package bankthreads;

public class Bank {

	private volatile Account[] accounts;
	
	public Bank(int n, double initialBalance) {
		accounts = new Account[n];
		for (int j = 0;j< n ; j++) {
			accounts[j] = new Account(initialBalance);
		}
	}
	

	public void transfer(int from, int to, double amount) 
	{
		synchronized(this) {
			if (accounts[from].getBalance() < amount) return;
			System.out.print(Thread.currentThread());
			accounts[from].withdraw(amount);
			System.out.printf(" %10.2f from %d to %d",  amount, from, to);
			accounts[to].deposit(amount);
		}
			System.out.printf(" Total Balance: %10.2f%n", getTotalBalance());
		
	}
	
	public double getTotalBalance() {
		double sum = 0;
		for (Account a: accounts)
			sum += a.getBalance();
		return sum;
	}
	
	public int size() {
		return accounts.length;
	}
}
