package threethreads;

public class ThreadTest {

	public static void main(String[] args) {
		A a = new A();
		a.setPriority(Thread.MAX_PRIORITY);
		a.start();
		new B().start();
		C c = new C();
		c.setPriority(Thread.MIN_PRIORITY);
		c.start();
	}
}
