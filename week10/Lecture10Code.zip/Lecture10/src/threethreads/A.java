package threethreads;

public class A extends Thread {

	public static final int DELAY = 0;
	
	public void run() {
		for (int i=1;i<=5;i++) {
			System.out.println("\t From ThreadA: i= " + i);
			
			try {
				Thread.sleep((int)(DELAY*Math.random()));
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Exit from A");
	}
}
