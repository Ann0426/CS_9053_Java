package threadqueues;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.*;

public class SynchronizedQueue {

	public Queue<Integer> syncQueue;
	Producer p;
	Consumer<Integer>[] consumers;
	
	public SynchronizedQueue(int numConsumers) {
		syncQueue = new ConcurrentLinkedQueue<Integer>();
		p = new Producer(syncQueue);
		consumers = new Consumer[numConsumers];
		for (int i= 0; i<consumers.length; i++) {
			consumers[i] = new Consumer<Integer>(syncQueue);
		}
		
		new Thread(p).start();
		for (Consumer<Integer> c : consumers) {
			new Thread(c).start();
		}
	}
	
	public static void main(String[] args) {
		SynchronizedQueue syncQ = new SynchronizedQueue(5);
	}
	

	
	
}
